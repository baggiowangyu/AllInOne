// dllmain.h : Declaration of module class.

class CATLShellExtIconHandlerModule : public CAtlDllModuleT< CATLShellExtIconHandlerModule >
{
public :
	DECLARE_LIBID(LIBID_ATLShellExtIconHandlerLib)
};

extern class CATLShellExtIconHandlerModule _AtlModule;
