// dllmain.h : Declaration of module class.

class CATLShellExtColumnHandlerModule : public CAtlDllModuleT< CATLShellExtColumnHandlerModule >
{
public :
	DECLARE_LIBID(LIBID_ATLShellExtColumnHandlerLib)
};

extern class CATLShellExtColumnHandlerModule _AtlModule;
