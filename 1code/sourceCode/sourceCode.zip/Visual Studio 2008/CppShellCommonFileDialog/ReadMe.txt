========================================================================
    WIN32 APPLICATION : CppShellCommonFileDialog Project Overview
========================================================================

/////////////////////////////////////////////////////////////////////////////
Summary:

The code sample demos the use of shell common file dialogs.


/////////////////////////////////////////////////////////////////////////////
References:

MSDN: Common Item Dialog
http://msdn.microsoft.com/en-us/library/bb776913(VS.85).aspx


/////////////////////////////////////////////////////////////////////////////