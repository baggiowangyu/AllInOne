// CppConsoleApplication.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <windows.h>

int wmain(int argc, wchar_t* argv[])
{
	wprintf(L"Test String");
    Sleep(50000);
    return 0;
}