// dllmain.h : Declaration of module class.

class CATLShellExtDragAndDropHandlerModule : public CAtlDllModuleT< CATLShellExtDragAndDropHandlerModule >
{
public :
	DECLARE_LIBID(LIBID_ATLShellExtDragAndDropHandlerLib)
};

extern class CATLShellExtDragAndDropHandlerModule _AtlModule;
