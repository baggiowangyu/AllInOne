// dllmain.h : Declaration of module class.

class CATLShellExtPropSheetHandlerModule : public CAtlDllModuleT< CATLShellExtPropSheetHandlerModule >
{
public :
	DECLARE_LIBID(LIBID_ATLShellExtPropSheetHandlerLib)
};

extern class CATLShellExtPropSheetHandlerModule _AtlModule;
