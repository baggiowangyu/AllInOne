//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ATLShellExtPropSheetHandler.rc
//
#define IDS_PROJNAME                    100
#define IDR_ATLSHELLEXTPROPSHEETHANDLER 101
#define IDR_FILEPROPSHEETEXT            102
#define IDR_WIN7DEVICEPROPSHEETEXT      103
#define IDD_FILE_PROPPAGE               106
#define IDD_WIN7DEVICE_PROPPAGE         107
#define IDC_FILENAME_STATIC             201
#define IDC_CHANGEWIN7DEVICEPROP_BN     201
#define IDC_CHANGEFILEPROP_BN           202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
