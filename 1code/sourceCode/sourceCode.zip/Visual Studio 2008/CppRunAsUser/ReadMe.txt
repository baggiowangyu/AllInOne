========================================================================
    WIN32 APPLICATION : CppRunAsUser Project Overview
========================================================================

/////////////////////////////////////////////////////////////////////////////
Summary:




/////////////////////////////////////////////////////////////////////////////
References:

MSDN: Starting an Interactive Client Process in C++
http://msdn.microsoft.com/en-us/library/aa379608(VS.85).aspx

CreateProcessAsUser() windowstations and desktops
http://support.microsoft.com/kb/165194

User32.dll or Kernel32.dll fails to initialize
http://support.microsoft.com/kb/184802


/////////////////////////////////////////////////////////////////////////////
