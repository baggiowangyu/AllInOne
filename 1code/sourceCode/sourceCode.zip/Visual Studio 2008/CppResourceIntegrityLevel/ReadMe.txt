========================================================================
    CONSOLE APPLICATION : CppResourceIntegrityLevel Project Overview
========================================================================

/////////////////////////////////////////////////////////////////////////////
Summary: 




/////////////////////////////////////////////////////////////////////////////
Prerequisite:

You must run this sample on Windows Vista or newer operating systems.


/////////////////////////////////////////////////////////////////////////////
Demo:




/////////////////////////////////////////////////////////////////////////////
Code Logic




/////////////////////////////////////////////////////////////////////////////
References:

MSDN Windows Integrity Mechanism Design 
http://msdn.microsoft.com/en-us/library/bb625963.aspx

Modifying the Mandatory Integrity Level for a Securable Object in Windows Vista 
http://blogs.msdn.com/cjacks/archive/2006/10/24/modifying-the-mandatory-integrity-level-for-a-securable-object-in-windows-vista.aspx

Windows Vista for Developers �C Part 4 �C User Account Control 
http://weblogs.asp.net/kennykerr/archive/2006/09/29/Windows-Vista-for-Developers-_1320_-Part-4-_1320_-User-Account-Control.aspx


/////////////////////////////////////////////////////////////////////////////
