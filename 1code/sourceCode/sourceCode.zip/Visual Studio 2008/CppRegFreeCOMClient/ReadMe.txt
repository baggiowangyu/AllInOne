========================================================================
    CONSOLE APPLICATION : CppRegFreeCOMClient Project Overview
========================================================================

/////////////////////////////////////////////////////////////////////////////
Summary:




/////////////////////////////////////////////////////////////////////////////
References:

Registration-Free Activation of .NET-Based Components: A Walkthrough
http://msdn.microsoft.com/en-us/library/ms973915.aspx

Isolated COM 
http://qualapps.blogspot.com/2007/06/isolated-com.html


/////////////////////////////////////////////////////////////////////////////