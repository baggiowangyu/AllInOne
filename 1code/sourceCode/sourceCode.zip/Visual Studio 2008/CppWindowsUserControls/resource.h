//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CppWindowsUserControls.rc
//
#define IDD_MAINDIALOG                  103
#define IDD_BUTTONDIALOG                130
#define IDD_COMBOBOXDIALOG              131
#define IDD_EDITDIALOG                  132
#define IDD_RICHEDITDIALOG              133
#define IDD_LISTBOXDIALOG               134
#define IDD_SCROLLBARDIALOG             135
#define IDD_STATICDIALOG                136
#define IDB_BITMAP1                     139
#define IDC_BUTTON_BUTTON               1000
#define IDC_BUTTON_COMBOBOX             1001
#define IDC_BUTTON_EDIT                 1002
#define IDC_BUTTON_LISTBOX              1003
#define IDC_BUTTON_SCROLLBAR            1004
#define IDC_BUTTON_STATIC               1005
#define IDC_BUTTON_RICHEDIT             1006
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
