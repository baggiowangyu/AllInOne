// CommonIncludes.h

#pragma once

#include "Resource.h"
#include "..\CppVSGetServiceInBackgroundThreadUI\Resource.h"
#include "Guids.h"
#include "..\CppVSGetServiceInBackgroundThreadUI\CommandIds.h"

#include "CppVSGetServiceInBackgroundThread.h"

#include "Package.h"


