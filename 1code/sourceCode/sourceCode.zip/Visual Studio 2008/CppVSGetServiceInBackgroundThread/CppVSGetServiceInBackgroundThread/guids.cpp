﻿// Guids.c
//

#include "initguid.h"
#include "Guids.h"
#include <VSShellInterfaces.h>

#define _MIDL_USE_GUIDDEF_ // Necessary to build without compilation errors
#include "CppVSGetServiceInBackgroundThread.c"

