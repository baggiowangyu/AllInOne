//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CppVSGetServiceInBackgroundThreadUI.rc
//

#define IDS_OFFICIALNAME                    100
#define IDS_PRODUCTDETAILS                  102
#define IDS_COMPANYNAME                     103
#define IDS_VERSION                         104
#define IDS_MINVSEDITION                    105


#define IDB_MENU_IMAGES                     300
#define IDB_FRAME_IMAGES                    301
#define IDI_PACKAGE_ICON                    400




// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        402
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           402
#endif
#endif
