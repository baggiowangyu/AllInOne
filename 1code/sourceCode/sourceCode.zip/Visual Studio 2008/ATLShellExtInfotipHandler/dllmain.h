// dllmain.h : Declaration of module class.

class CATLShellExtInfotipHandlerModule : public CAtlDllModuleT< CATLShellExtInfotipHandlerModule >
{
public :
	DECLARE_LIBID(LIBID_ATLShellExtInfotipHandlerLib)
};

extern class CATLShellExtInfotipHandlerModule _AtlModule;
