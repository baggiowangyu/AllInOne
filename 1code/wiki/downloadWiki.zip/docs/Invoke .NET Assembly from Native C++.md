# {"Invoke .NET Assembly from Native C++ Code"}
>{Writer: [Jialiang Ge](http://www.codeplex.com/site/users/view/Jialiang)}>
 
[Solution 1. Use a C++/CLI wrapper](http://1code.codeplex.com/wikipage?title=Invoke%20.NET%20Assembly%20from%20Native%20C%2b%2b#CLIWrapper)
[Solution 2. Host CLR](http://1code.codeplex.com/wikipage?title=Invoke%20.NET%20Assembly%20from%20Native%20C%2b%2b#HostCLR)
[Solution 3. Convert .NET assembly to a COM server, and call it from C++ through .NET-COM interop](http://1code.codeplex.com/wikipage?title=Invoke%20.NET%20Assembly%20from%20Native%20C%2b%2b#COMInterop)
 
{anchor:CLIWrapper}
## {"Solution 1. Use a C++/CLI wrapper"} 
Samples: 
* **CSClassLibrary** (a C# class library)
* **CppCLINETAssemblyWrapper** ({"a C++/CLI wrapper of the C# class library CSClassLibrary"}) 
* **CppCallNETAssemblyWrapper** ({"a native C++ application that invokes CSClassLibrary through CppCLINETAssemblyWrapper"}) 
{"The native C++ sample application CppCallNETAssemblyWrapper calls the .NET class defined in the C# class library CSClassLibrary through the C++/CLI wrapper CppCLINETAssemblyWrapper."}
 
![Download](Invoke .NET Assembly from Native C++_Download.png|http://1code.codeplex.com/releases) Download the [All-In-One Code Framework (Library)](http://1code.codeplex.com/releases/view/44540#DownloadId=119923) package.
 
![](Invoke .NET Assembly from Native C++_ CLIWrapper.png)

{anchor:HostCLR}
## {"Solution 2. Host CLR"}
Samples: 
* **CSClassLibrary** ({"a C# class library"})
* **CppHostCLR** ({"a native C++ application that host CLR and load the .NET assembly CSClassLibrary"})
{"The native C++ sample application CppHostCLR hosts CLR, instantiates a type in the .NET assembly CSClassLibrary.dll and calls its methods."} Both [.NET Framework 1.x Hosting Interfaces](http://msdn.microsoft.com/en-us/library/ms164318.aspx) and [.NET Framework 2.0 Hosting Interfaces](http://msdn.microsoft.com/en-us/library/ms164336.aspx) are demonstrated in the code samples.
 
![Download](Invoke .NET Assembly from Native C++_Download.png|http://1code.codeplex.com/releases) Download the [All-In-One Code Framework (Library)](http://1code.codeplex.com/releases/view/44540#DownloadId=119923) package.
 
![](Invoke .NET Assembly from Native C++_ HostCLR.png)

{anchor:COMInterop}
## {"Solution 3. Convert .NET assembly to a COM server, and call it from C++ through .NET-COM interop"}
Samples:
* **CSDllCOMServer** ({"a C# class library converted to an in-process COM server"})
* **CppCOMClient** ({"a native C++ application that invokes the C# in-process COM server CSDllCOMServer"})
{"The native C++ sample application CppCOMClient invokes the in-process COM server CSDllCOMServer that was converted from a C# class library."}
 
![Download](Invoke .NET Assembly from Native C++_Download.png|http://1code.codeplex.com/releases) Download the [All-In-One Code Framework (COM)](http://1code.codeplex.com/releases/view/44540#DownloadId=119919) package.
 
![](Invoke .NET Assembly from Native C++_ COMInterop.png)