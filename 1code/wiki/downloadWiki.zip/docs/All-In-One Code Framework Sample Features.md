## All-In-One Code Framework Sample Features
 
* **All-In-One**
	* Our goal is that typical code samples of ALL Microsoft development technologies are in one solution. It gives developers a one-stop experience.
 
* **Code samples are driven by customers**
	* The project team listens to developers’ pains and needs in communities, MSDN/ASP.NET/Silverlight forums, social media, and Microsoft Developer Support. We write code samples for developers’ frequently asked programming tasks and shares the samples in a short sample publishing cycle.  
	* We provide [a new, free code sample request service](http://1code.codeplex.com/wikipage?title=NEW%2c%20FREE%20Code%20Sample%20Request%20Service%20from%20Microsoft%20All-In-One%20Code%20Framework). Developers are encouraged to submit code sample topics to our site, or vote for existing sample topics. Microsoft engineers will pick the topics with the top votes, and provide code samples accordingly, and it’s all FREE. 
 
* **Multi-languages**
	* The project tries to demo each coding scenario in three programming languages (C++, C#, VB.NET).
	* The samples are localized to benefit non-English countries. (e.g. [the Chinese edition of All-In-One Code Framework](http://1codechs.codeplex.com/))

* **Integrated with Visual Studio + Sample Search Portal (_coming soon_)**
	* The project team is developing an interesting initiative to help developers search and use the code samples more easily. The team plans to move the centralized code samples to the cloud, provide a code search and sample download web service, and integrate the service with Visual Studio through a Visual Studio add-in. In this way, developers can instantly search code in IDE, and download samples on demand, instead of downloading the entire package.  
    ![](All-In-One Code Framework Sample Features_blueprint.bmp)