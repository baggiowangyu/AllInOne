
## Examples for COM

![](All-In-One Code Framework Examples_COM.png)
|| Name || Description || Owner ||
| CSDllCOMServer | An in-process COM server in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBDllCOMServer  | An in-process COM server in VB.NET | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLDllCOMServer | An in-process ATL COM Server | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSExeCOMServer | An out-of-process COM Server in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLExeCOMServer | An out-of-process ATL COM Server | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSCOMService | An out-of-process COM Service in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLCOMService | An out-of-process ATL COM Service | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSServicedComponent | A serviced component written in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBServicedComponent | A serviced component written in VB.NET | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| MFCActiveX | A MFC ActiveX Control | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| MFCSafeActiveX | A MFC ActiveX Control Safe for Scripting and Initialization | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLActiveX | An ATL ActiveX Control | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSActiveX | A C# ActiveX Control | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBActiveX | A VB.NET ActiveX Control | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLCOMClient | Use COM servers in an ATL application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppCOMClient | Use COM servers in a {"C++"} application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSCOMClient | Host ActiveX controls and use COM servers in a C# application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBCOMClient | Host ActiveX controls and use COM servers in a VB.NET application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| MFCCOMClient | Host ActiveX controls and use COM servers in a MFC application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| HTMLEmbedActiveX | Host ActiveX controls in HTML | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |

## Examples for Windows 7

![](All-In-One Code Framework Examples_Win7.png)
|| Name || Description || Owner ||
| CSWin7TriggerStartService | Win7 Trigger Start Service (C#) | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBWin7TriggerStartService | Win7 Trigger Start Service (VB.NET) | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppWin7TriggerStartService | Win7 Trigger Start Service ({"C++"}) | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSWin7ShellLibrary | Operate on Win7 Shell Library (C#) | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBWin7ShellLibrary | Operate on Win7 Shell Library (VB.NET) | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppWin7ShellLibrary | Operate on Win7 Shell Library ({"C++"}) | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSWin7TaskbarAppID | Win7 Application ID in taskbar (C#) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| VBWin7TaskbarAppID | Win7 Application ID in taskbar (VB.NET) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CppWin7TaskbarAppID | Win7 Application ID in taskbar ({"C++"}) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSWin7TaskbarOverlayIcons | Win7 Overlay Icons in taskbar (C#) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| VBWin7TaskbarOverlayIcons | Win7 Overlay Icons in taskbar (VB.NET) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CppWin7TaskbarOverlayIcons | Win7 Overlay Icons in taskbar ({"C++"}) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSWin7TaskbarProgressbar | Win7 Progressbar in taskbar (C#) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| VBWin7TaskbarProgressbar | Win7 Progressbar in taskbar (VB.NET) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CppWin7TaskbarProgressBar | Win7 Progressbar in taskbar ({"C++"}) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSWin7TaskbarThumbnail | Win7 Thumbnail in taskbar (C#) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| VBWin7TaskbarThumbnail | Win7 Thumbnail in taskbar (VB.NET) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSWin7TaskbarJumpList | Win7 Jumplist in taskbar (C#) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| VBWin7TaskbarJumpList | Win7 Jumplist in taskbar (VB.NET) | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSWin7Direct2D | Win7 new 2-D graphics API (C#) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |
| VBWin7Direct2D | Win7 new 2-D graphics API (VB.NET) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |
| CppWin7Direct2D | Win7 new 2-D graphics API ({"C++"}) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |

## Examples for Application Compatibility

![](All-In-One Code Framework Examples_AppCompat.png)
|| Name || Description || Owner ||
| CSCheckOSVersion | Check OS Version in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppCheckOSVersion | Check OS Version in {"C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |

## Examples for Silverlight

![](All-In-One Code Framework Examples_Silverlight.png)
|| Name || Description || Owner ||
| CSSL3PlaneProjection | Plane projection in SL3 (C#) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| VBSL3PlaneProjection | Plane projection in SL3 (VB.NET) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| CSSL3FullScreen | Full screen in SL3 (C#) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| VBSL3FullScreen | Full screen in SL3 (VB.NET) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| CSSL3PixelShader | Pixel shader in SL3 (C#) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| VBSL3PixelShader | Pixel shader in SL3 (VB.NET) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| CSSL3Input | Mouse and keyboard inputs in SL3 | [Moggle](http://www.codeplex.com/site/users/view/Moggle) |
| VBSL3Input | Mouse and keyboard inputs in SL3 | [Moggle](http://www.codeplex.com/site/users/view/Moggle) |
| CSSL3Text | Work with text in SL3 (C#) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |
| VBSL3Text | Work with text in SL3 (VB.NET) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |
| XAMLSL3Text | Work with text in SL3 (Xaml) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |
| XAMLSL3StyleControlTemplate | Style and control template in SL3 | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |
| XAMLSL3SplashScreen | Splash screen in SL3 (XAML) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| CSSL3DeepZoom | Deep zoom in SL3 (C#) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |
| VBSL3DeepZoom | Deep zoom in SL3 (VB.NET) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |
| CSSL3CustomControl | Custom control in SL3 (C#) | [Moggle](http://www.codeplex.com/site/users/view/Moggle) |
| VBSL3CustomControl | Custom control in SL3 (VB.NET) | [Moggle](http://www.codeplex.com/site/users/view/Moggle) |
| CSSL3Animation | Animation in SL3 (C#) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| VBSL3Animation | Animation in SL3 (VB.NET) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| CSSL3WriteableBitmap | Writeable bitmap in SL3 (C#) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |
| CSSL3LocalMessage | Communication between local Silverlight-based applications (C#) | [Moggle](http://www.codeplex.com/site/users/view/Moggle) |
| VBSL3LocalMessage | Communication between local Silverlight-based applications (VB.NET) | [Moggle](http://www.codeplex.com/site/users/view/Moggle) |
| CSSL3MediaElement | Silverlight3 MediaElement (C#) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| VBSL3MediaElement | Silverlight3 MediaElement (VB.NET) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| CSSL3OOB | Out-of-browser Silverlight3 application (C#) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |
| VBSL3OOB | Out-of-browser Silverlight3 application (VB.NET) | [shanaolanxing](http://www.codeplex.com/site/users/view/shanaolanxing) |

## Examples for ASP.NET

![](All-In-One Code Framework Examples_ASPNET.png)
|| Name || Description || Owner ||
| VBASPNETFileUpload | File upload in ASP.NET (VB.NET) | [BravoYang](http://www.codeplex.com/site/users/view/BravoYang) |
| VBASPNETLocalization | Globalization and localization in ASP.NET (VB.NET) | [BravoYang](http://www.codeplex.com/site/users/view/BravoYang) |
| CSASPNETCascadingDropDownList | Cascading Drop Down List in ASP.NET (C#) | [ThomasSun](http://www.codeplex.com/site/users/view/ThomasSun) |
| CSASPNETPageValidation | ASP.NET Validator Controls (C#) | [LiZongQing](http://www.codeplex.com/site/users/view/LiZongQing) |
| CSASPNETAjaxExtender | ASP.NET AJAX Extender (C#) | [VinceXu](http://www.codeplex.com/site/users/view/VinceXu) |
| CSASPNETMVCFileDownload | ASP.NET MVC File Download sample | [stcheng](http://www.codeplex.com/site/users/view/stcheng) |
| CSASPNETOutputCache | Output cache in ASP.NET (C#) | [ThomasSun](http://www.codeplex.com/site/users/view/ThomasSun) |
| CSASPNETMenu | Menu in ASP.NET (C#) | [LiZongQing](http://www.codeplex.com/site/users/view/LiZongQing) |
| VBASPNETMasterPage | ASP.NET Master Page (VB.NET) | [BravoYang](http://www.codeplex.com/site/users/view/BravoYang) |
| CSASPNETDataPager | ASP.NET DataPager control (C#) | [Kjian](http://www.codeplex.com/site/users/view/Kjian) |
| CSASPNETGridView | ASP.NET GridView control (C#) | [Kjian](http://www.codeplex.com/site/users/view/Kjian) |

## Examples for Data Access

![](All-In-One Code Framework Examples_Data Access.png)
|| Name || Description || Owner ||
| CSUseADO | Use ADO in a C# application | [RongchunZhang](http://www.codeplex.com/site/users/view/RongchunZhang) |
| CppUseADO | Use ADO in a {"C++"} application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSUseADONET | Use ADO.NET in a C# application | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CppUseADONET | Use ADO.NET in a {"C++"} application | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSADONETDataService | ADO.NET Data Service in C# | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| VBADONETDataService | ADO.NET Data Service in VB.NET | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSADONETDataServiceClient | Use ADO.NET Data Service in C# | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| VBADONETDataServiceClient | Use ADO.NET Data Service in VB.NET | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSADONETDataServiceSL3Client | Use ADO.NET Data Service in Silverlight (C#) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| VBADONETDataServiceSL3Client | Use ADO.NET Data Service in Silverlight (VB.NET) | [allenc](http://www.codeplex.com/site/users/view/allenc) |
| CSLinqToObject | Use LINQ to Objects in C# | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |
| VBLinqToObject | Use LINQ to Objects in VB.NET | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSLinqToSQL | Use LINQ to SQL in C# | [RongchunZhang](http://www.codeplex.com/site/users/view/RongchunZhang) |
| VBLinqToSQL | Use LINQ to SQL in VB.NET | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSLinqToEntities | Use LINQ to Entities in C# | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| VBLinqToEntities | Use LINQ to Entities in VB.NET | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSLinqToDataSets | Use LINQ to DataSets in C# | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| VBLinqToDataSets | Use LINQ to DataSets in VB.NET | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSLinqExtension | Extend LINQ in C# | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| SQLServer2005DB | A SQL Server 2005 Database project | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |

## Examples for Office

![](All-In-One Code Framework Examples_Office.png)
|| Name || Description || Owner ||
| CSOutlookUIDesigner | Customize Outlook UI using VSTO Designers (C#) | [midnightfrank](http://www.codeplex.com/site/users/view/midnightfrank) |
| VBOutlookRibbonDesigner | Customize Outlook UI using VSTO Designers (VB.NET) | TimLi |
| CSOutlookRibbonXml | Customize Outlook UI using Ribbon XML (C#) | [midnightfrank](http://www.codeplex.com/site/users/view/midnightfrank) |
| VBOutlookRibbonXml | Customize Outlook UI using Ribbon XML (VB.NET) | TimLi |
| CSVstoExcelWorkbook | Customize Excel workbook using VSTO | [midnightfrank](http://www.codeplex.com/site/users/view/midnightfrank) |
| CSVstoVBAInterop | VSTO Interop with Excel VBA macros | [midnightfrank](http://www.codeplex.com/site/users/view/midnightfrank) |
| CSVstoGetWrapperObject | Get VSTO Wrapper Object | [midnightfrank](http://www.codeplex.com/site/users/view/midnightfrank) |
| CSExcelAutomationAddIn | Excel Automation Add-in in C# | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |
| VBExcelAutomationAddIn | Excel Automation Add-in in VB.NET | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |
| CSVstoServerDocument | Use VSTO ServerDocument class | [midnightfrank](http://www.codeplex.com/site/users/view/midnightfrank) |
| CSOfficeSharedAddIn | Office Shared AddIn in C# | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |
| CppOfficeManagedCOMAddInShim | Shim of Office Managed COM AddIn | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |
| CSAutomateWord | Automate Word in a C# application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBAutomateWord | Automate Word in a VB.NET application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppAutomateWord | {"Automate Word in a VC++ application"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSAutomateExcel | Automate Excel in a C# application | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |
| VBAutomateExcel | Automate Excel in a VB.NET application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppAutomateExcel | {"Automate Excel in a VC++ application"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSAutomateOutlook | Automate Outlook in a C# application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBAutomateOutlook | Automate Outlook in a VB.NET application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppAutomateOutlook | {"Automate Outlook in a VC++ application"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSAutomatePowerPoint | Automate PowerPoint in a C# application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBAutomatePowerPoint | Automate PowerPoint in a VB.NET application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppAutomatePowerPoint | {"Automate PowerPoint in a VC++ application"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |

## Examples for Language

![](All-In-One Code Framework Examples_Language.png)
|| Name || Description || Owner ||
| CSCodeDOM | CodeDOM in C# | [midnightfrank](http://www.codeplex.com/site/users/view/midnightfrank) |
| VBCodeDOM | CodeDOM in VB.NET | [midnightfrank](http://www.codeplex.com/site/users/view/midnightfrank) |

## Examples for Library

![](All-In-One Code Framework Examples_Library.png)
|| Name || Description || Owner ||
| CppDllExport | A {"C++"} dynamic library export symbols | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppImplicitlyLinkDll | {"C++"} implicitly links a DLL | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppDelayloadDll | {"C++"} delay-loads a DLL | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppLoadLibrary | {"C++"} dynamically loads a DLL | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSLoadLibrary | C# dynamically loads a native DLL | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSPInvokeDll | C# P/Invokes a native DLL | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSClassLibrary | A C# Class Library | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppHostCLR | {"C++"} hosts CLR and loads a .NET assembly | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSReflection | C# dynamically loads and uses the types of an assembly | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSEmitAssembly | C# emits an assembly with types in runtime | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBClassLibrary | A VB.NET Class Library | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBReflection | VB.NET dynamically loads and uses the types of an assembly | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppStaticLibrary | A {"C++"} Static Library | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppStaticallyLinkLib | {"C++"} statically links a static library | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppCLIWrapLib | {"C++/CLI wrapper of native C++ lib"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |

## Examples for IPC and RPC

![](All-In-One Code Framework Examples_IPC and RPC.png)
|| Name || Description || Owner ||
| CppNamedPipeServer | A named-pipe server written in {"C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppNamedPipeClient | A named-pipe client written in {"C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSNamedPipeServer | A named-pipe server written in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang), [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| CSNamedPipeClient | A named-pipe client written in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang), [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| CppMailslotServer | A mailslot server written in {"C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppMailslotClient | A mailslot client written in {"C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSMailslotServer | A mailslot server written in C# | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| CSMailslotClient | A mailslot client written in C# | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| CppFileMappingServer | Create shared memory in {"C++"} | [hongyes](http://www.codeplex.com/site/users/view/hongyes) |
| CppFileMappingClient | Access shared memory in {"C++"} | [hongyes](http://www.codeplex.com/site/users/view/hongyes) |
| CSFileMappingServer | Create shared memory in C# | [hongyes](http://www.codeplex.com/site/users/view/hongyes) |
| CSFileMappingClient | Access shared memory in C# | [hongyes](http://www.codeplex.com/site/users/view/hongyes) |
| CSRemotingServer | A .NET Remoting server written in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSRemotingClient | A .NET Remoting client written in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBRemotingServer | A .NET Remoting server written in VB.NET | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBRemotingClient | A .NET Remoting server written in VB.NET | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| {"CSReceiveWM_COPYDATA"} | Receive WM_COPYDATA in C# | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| {"CSSendWM_COPYDATA"} | Send WM_COPYDATA in C# | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| {"CppReceiveWM_COPYDATA"} | Receive WM_COPYDATA in {"C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| {"CppSendWM_COPYDATA"} | Send WM_COPYDATA in {"C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSSocketServer | A socket server written in C# | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| CSSocketClient | A socket client written in C# | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| MFCClipboard | Use clipboard in MFC | [hongyes](http://www.codeplex.com/site/users/view/hongyes) |

## Examples for Windows

![](All-In-One Code Framework Examples_Windows.png)
| CppWindowsDialog | {"Windows Dialog Box in C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppWindowsUserControls | {"Use user-controls in C++ Windows application"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppWindowsCommonControls | {"Use common-controls in C++ Windows application"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppWindowsSubclassing | {"Subclass Windows in C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |

## Examples for WinForm

![](All-In-One Code Framework Examples_WinForm.png)
|| Name || Description || Owner ||
| CSWinFormDataBinding | WinForm Data-binding in C# | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormLocalization | Localize WinForms application | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormDesigner | WinForm Designers in C# | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormControls | WinForm Control Customization in C# | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormObjPersistence | Object Persistence in WinForm | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormDragAndDrop | Drag and Drop operations in WinForm | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormGraphics | {"Use GDI+ to do Graphics in WinForm"} | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormTimeConsumingOpr | Time-consuming Operations in WinForm | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormPrinting | Printing in WinForm | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormPassValueBetweenForms | Pass Value between WinForms | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormDataGridView | DataGridView in WinForm | [ZhiXin](http://www.codeplex.com/site/users/view/ZhiXin) |
| CSWinFormSplashScreen | WinForm Splash Screen | [Bruce](http://www.codeplex.com/site/users/view/Bruce) |
| CSWinFormBindingNestedProperties | WinForms binding nested properties | Linda |

## Examples for WPF

![](All-In-One Code Framework Examples_WPF.png)
|| Name || Description || Owner ||
| CSWPFThreading | Threading in WPF | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |

## Examples for XML

![](All-In-One Code Framework Examples_XML.png)
|| Name || Description || Owner ||
| CSLinqToXml | Use LINQ to XML in C# | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| VBLinqToXml | Use LINQ to XML in VB.NET | [LingzhiSun](http://www.codeplex.com/site/users/view/LingzhiSun) |
| CSXmlSerialization | XML Serialization (C#) | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |
| VBXmlSerialization | XML Serialization (VB.NET) | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |
| CSXmlGeneral | General operations of XML files (C#) | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |
| VBXmlGeneral | General operations of XML files (VB.NET) | [Colbert](http://www.codeplex.com/site/users/view/Colbert) |

## Examples for File System

![](All-In-One Code Framework Examples_File System.png)
|| Name || Description || Owner ||
| CppSynchronousIO | {"Synchronous I/O in C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppAsynchronousIO | {"Asynchronous I/O in C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppSparseFile | Sparse file operations in {"C++"} | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSSparseFile | Sparse file operations in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBSparseFile | Sparse file operations in VB.NET | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppFileHandle | Operations about file handle | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSListFilesInDirectory | List files in directory using C# | [midnightfrank](http://www.codeplex.com/site/users/view/midnightfrank) |
| VBListFilesInDirectory | List files in directory using VB.NET | [midnightfrank](http://www.codeplex.com/site/users/view/midnightfrank) |

## Examples for Security

![](All-In-One Code Framework Examples_Security.png)
|| Name || Description || Owner ||
| CSEncryption | Use encryption in C# | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| CSDigitalSignature | Use digital signature in C# | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| CSUac | UAC Elevation in C# | [Fisnik](http://www.codeplex.com/site/users/view/Fisnik) |
| VBUac | UAC Elevation in VB.NET | [Fisnik](http://www.codeplex.com/site/users/view/Fisnik) |
| CppUac | {"UAC Elevation in VC++"} | [RongchunZhang](http://www.codeplex.com/site/users/view/RongchunZhang) |
| CSCustomAuthorization | Implement Custom Authorization in C# | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| CSControlFirewall | Control Windows Firewall in C# | [Fisnik](http://www.codeplex.com/site/users/view/Fisnik) |
| CSImpersonateUser | Impersonation in C# | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| VBImpersonateUser | Impersonation in VB.NET | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |
| CppImpersonateUser | Impersonation in {"C++"} | [Riquel](http://www.codeplex.com/site/users/view/Riquel) |

## Examples for Visual Studio

![](All-In-One Code Framework Examples_VS.png)
|| Name || Description || Owner ||
| CSTFSWorkItemObjectModel | Use TFS WorkItem Object Model in C# | [billwg](http://www.codeplex.com/site/users/view/billwg) |
| CSVSPackage | VS Package in C# | [RongchunZhang](http://www.codeplex.com/site/users/view/RongchunZhang) |
| CSVSPackageState | VS Package: State Persisting | [hongyes](http://www.codeplex.com/site/users/view/hongyes) |
| CSVSToolWindow | VSPackage with a tool window | [RongchunZhang](http://www.codeplex.com/site/users/view/RongchunZhang) |
| CSTFSDataWarehouseAdapter | TFS Data Warehouse Adapter | [billwg](http://www.codeplex.com/site/users/view/billwg) |

## Examples for Windows Shell

![](All-In-One Code Framework Examples_Shell.png)
|| Name || Description || Owner ||
| ATLShellExtDragAndDropHandler | Shell Drag and Drop Extension Handler | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLShellExtInfotipHandler | Shell Infotip Extension Handler | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLShellExtPropSheetHandler | Shell Property Sheet Extension Handler | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLShellExtContextMenuHandler | Shell Context Menu Extension Handler | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLShellExtIconHandler | Shell Icon Extension Handler | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLShellExtIconOverlayHandler | Shell Icon Overlay Extension Handler | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| ATLShellExtColumnHandler | Shell extension column handler | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CSShellKnownFolders | Shell Knownfolder API (C#) | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBShellKnownFolders | Shell Knownfolder API (VB.NET) | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppShellKnownFolders | Shell Knownfolder API ({"C++"}) | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |

## Examples for Hook

![](All-In-One Code Framework Examples_Hook.png)
|| Name || Description || Owner ||
| CSWindowsHook | Windows Hook in a C# application | [RongchunZhang](http://www.codeplex.com/site/users/view/RongchunZhang) |
| CppWindowsHook | {"Windows Hook in a C++ application"} | [RongchunZhang](http://www.codeplex.com/site/users/view/RongchunZhang) |
| CppHookDll | Hook Dll injected into other processes | [RongchunZhang](http://www.codeplex.com/site/users/view/RongchunZhang) |

## Examples for Console

![](All-In-One Code Framework Examples_Console.png)
|| Name || Description || Owner ||
| CppRedirectConsole | {"C++ app redirects console IO"} | [hongyes](http://www.codeplex.com/site/users/view/hongyes) |

## Examples for Network

![](All-In-One Code Framework Examples_Network.png)
|| Name || Description || Owner ||
| CSSMTPSendEmail | Send email using SMTP in C# | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| VBSMTPSendEmail | Send email using SMTP in VB.NET | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |

## Examples for Diagnostics

![](All-In-One Code Framework Examples_Diagnostics.png)
|| Name || Description || Owner ||
| CppStackOverflow | Stack overflow in a Win32 application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppStackCorruption | Stack corruption in a Win32 application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppHeapCorruption | Heap corruption in a Win32 application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
| CppResourceLeaks | Resource leaks in a Win32 application | [Jialiang](http://www.codeplex.com/site/users/view/Jialiang) |
