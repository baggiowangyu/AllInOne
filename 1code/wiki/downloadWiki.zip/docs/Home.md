>{**Follow us on** ![rss](Home_rss.jpg|https://1code.blog/feed) ![Code sample blogs](Home_blog.png|https://1code.blog/)  ![Facebook](Home_facebook.png|http://www.facebook.com/1code.blog)  ![Twitter](Home_twitter.png|http://twitter.com/1codeblog)}>
![Sample Browser](Home_samplebrowserreleaseon20132.png|http://apps.microsoft.com/windows/en-US/app/sample-browser/6fd83c79-a2fc-4887-9284-535681eb3993)
### Updates
{rss:url=http://1code.blog/feed/,max=10,titlesOnly=true}

<![Introduction Video](Home_video.png|http://www.microsoft.com/showcase/en/us/details/40015bbc-2ded-4aba-9613-2c5a47ee3084)
* Are you frustrated by the lack of code samples for certain programming tasks? 
* Have you struggled to quickly get started with a technique? 
* Have you expected someone to write code samples for you based on your requests for free? 
* Is a one-stop code sample library for all Microsoft DEV technologies attractive to you? 
: If your answer is YES to any of these questions,
: **Microsoft All-In-One Code Framework** is for you!
 
<![](Home_line.png) 
 
The **Microsoft All-In-One Code Framework** is a **free, centralized code sample library driven by developers' needs**. Our goal is to provide typical code samples for all Microsoft development technologies, and reduce developers' efforts in solving typical programming tasks. 

Our team listens to developers’ pains in MSDN forums, social media and various developer communities. We write **code samples** based on developers’ frequently asked programming tasks, and allow developers to **[download](http://1code.codeplex.com/releases)** them with a short code sample publishing cycle. Additionally, our team offers **[a free code sample request service](http://1code.codeplex.com/wikipage?title=Request%20Code%20Sample%20from%20Microsoft%20All-In-One%20Code%20Framework)**. This service is a proactive way for our developer community to obtain code samples for certain programming tasks directly from Microsoft.  

<![](Home_line.png) 
#### Code Samples
<![scenario-focused code samples](Home_listen.png)
Different from traditional feature-focused code samples, Microsoft All-In-One Code Framework provides **scenario-focused** code samples driven by customers' real-world programming pains and needs.   We listen in developer communities and the sample request service, collect developers' typical programming scenarios, and compose them into code samples.

Since we launched the project in 2009, we have created 700+ scenario-focused code samples covering 23 Microsoft development technologies.  The sample repository is growing by 6 samples per week.  To search and download the code samples, you can either visit [http://aka.ms/onecodeingallery](http://aka.ms/onecodeingallery), or use our Sample Browser to enjoy the flexible download experience. 
  
<![](Home_line.png) 
#### Sample Of The Day
![Sample Of The Day](Home_sampleoftheday.png|http://1code.codeplex.com/wikipage?title=SampleOfTheDay)
Every day is an opportunity to learn something or discover something new. 
 
Microsoft All-In-One Code Framework offers **"Sample of the Day"**.  "Sample of the Day" introduces one amazing code sample every 24 hours that demonstrates the most typical programming scenarios of different Microsoft technologies.  If you are curious about and passionate for learning something new, follow [the “Sample of the Day” RSS feed](http://blogs.msdn.com/b/codefx/rss.aspx?tags=SampleOfTheDay) or visit [the "Sample of the Day" homepage](http://1code.codeplex.com/wikipage?title=SampleOfTheDay), and share your feedback with us [mailto:onecode@microsoft.com](mailto:onecode@microsoft.com).
 
{rss:url=http://blogs.msdn.com/b/codefx/rss.aspx?tags=SampleOfTheDay,max=5,titlesOnly=true}
 
<![](Home_line.png) 
#### Sample Browser & Sample Browser Visual Studio Extension
To make the sample search, download and management experience hassle free and enjoyable, Microsoft All-In-One Code Framework and MSDN Samples Gallery innovated the **[Sample Browser](http://aka.ms/samplebrowser)** and **[Sample Browser Visual Studio Extension](http://aka.ms/samplebrowservsx)**.   Developers can enjoy 700+ code samples from Microsoft All-In-One Code Framework with a few simple clicks. 
 
![Sample Browser](Home_samplebrowser.png|http://aka.ms/samplebrowser) 
![Sample Browser Visual Studio Extension](Home_samplebrowservsx.png|http://aka.ms/samplebrowservsx)
 
<![](Home_line.png) 
#### Code Sample Request Service
<![Sample Request Service](Home_samplerequestbanner.png)
Microsoft All-In-One Code Framework team announces a new **[code sample request service](http://1code.codeplex.com/wikipage?title=Request%20Code%20Sample%20from%20Microsoft%20All-In-One%20Code%20Framework&referringTitle=Documentation)**. This is a proactive way for our developer community to obtain code samples for certain programming tasks directly from Microsoft if developers cannot find the wanted code samples in the repository.  We want to alleviate the frustration felt by developers.

Developers are encouraged to submit code sample requests dealing with any Microsoft development technologies to our site. At the same time, developers can now vote for newly submitted or existing code sample topics. Here’s the exciting part! Microsoft engineers will then pick the requests with the highest number of votes and provide the code samples.
 
<![](Home_line.png) 
#### C++ and .NET Coding Guideline
<![Coding Guideline](Home_guidelinebanner.png|http://1code.codeplex.com/wikipage?title=All-In-One%20Code%20Framework%20Coding%20Standards&referringTitle=Documentation)
Microsoft All-In-One Code Framework team shares the [coding guideline for native C++ and .NET (C# and VB.NET) programming](http://1code.codeplex.com/wikipage?title=All-In-One%20Code%20Framework%20Coding%20Standards&referringTitle=Documentation).  The coding guideline is used by the project team to create code samples.   This standard derives from the experience of product development efforts and is continuously evolving.  If you discover a new best practice or a topic that is not covered, please bring that to the attention of the [All-In-One Code Framework Project Group](mailto:onecode@microsoft.com) and have the conclusion added to this document.

No set of guidelines will satisfy everyone. The goal of a standard is to create efficiencies across a community of developers. Applying a set of well-defined coding standards will result in code with fewer bugs, and better maintainability. Adopting an unfamiliar standard may be awkward initially, but the pain fades quickly and the benefits are quickly realized, especially when you inherit ownership of others' code.
 
<![](Home_line.png) 
#### Customer Feedback
We look forward to hearing your feedback and suggestions.  Please email [onecode@microsoft.com](mailto:onecode@microsoft.com) or [fill out a quick survey](http://support.microsoft.com/common/survey.aspx?scid=sw;en;1759&showpage=1) to tell us your requirements.
<![](Home_customerfeedback.png)
"An evolution to next-level, example-centric coding for developers"
[Softpedia news media](http://news.softpedia.com/)

"The samples could definitely spare you from some horrible bugs”
[Kate Gregory (Regional Director/MVP, Microsoft)](http://www.microsoftregionaldirectors.com/profile.aspx?rd=1144)
 
 
 
 
"An innovative piece of work that makes developers’ life much easier”
[Arjun Bahree (Practice Leadership, Wipro Infotech)](http://in.linkedin.com/in/arjunbahree)

"OK, I am officially Loving the new All-In-One Code Framework!"
[Dirk Strauss (Software Developer)](http://twitter.com/#!/DirkStrauss)

"Great Job Done Microsoft.  You guyz are truly brilliant and genius"
[Abdullah Rehman](http://blogs.msdn.com/b/codefx/archive/2011/08/09/microsoft-all-in-one-code-framework-august-code-sample-updates.aspx)

<![](Home_line.png)
#### Visitors
![http://www.myworldmaps.net/map.ashx/c125e1da-2ea9-4c99-b8fa-d028257c3700/thumb_160](Home_http://www.myworldmaps.net/mapstats.aspx?mapid=c125e1da-2ea9-4c99-b8fa-d028257c3700) ![http://www3.clustrmaps.com/counter/index2.php?url=http://cfx.codeplex.com](Home_http://www3.clustrmaps.com/counter/maps.php?url=http://cfx.codeplex.com) ![http://www.maploco.com/vm24/s/4050230.png](Home_http://m.maploco.com/details/c2c2et6e)