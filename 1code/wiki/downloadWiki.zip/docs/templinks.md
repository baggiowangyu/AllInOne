[url](http://1code.codeplex.com)
[url](http://www.microsoft.com/showcase/en/us/details/40015bbc-2ded-4aba-9613-2c5a47ee3084)
[url](http://blogs.msdn.com/b/codefx/)
[url](http://www.microsoft.com/presspass/features/2011/jan11/01-13codeframework.mspx)