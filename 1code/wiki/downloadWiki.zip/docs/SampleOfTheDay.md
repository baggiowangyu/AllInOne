![Sample Of The Day](SampleOfTheDay_sampleoftheday.png)

Every day is an opportunity to learn something or discover something new.  Learn one sample every day, be coding master in a year!
 
Microsoft All-In-One Code Framework offers **"Sample of the Day"**.  "Sample of the Day" introduces one amazing code sample every 24 hours that demonstrates the most typical programming scenarios of different Microsoft technologies.  If you are curious about and passionate for learning something new, follow [the “Sample of the Day” RSS feed](http://blogs.msdn.com/b/codefx/rss.aspx?tags=SampleOfTheDay) or visit [the "Sample of the Day" homepage](http://1code.codeplex.com/wikipage?title=SampleOfTheDay), and share your feedback with us [mailto:onecode@microsoft.com](mailto:onecode@microsoft.com).
 
<![](SampleOfTheDay_rssslide.jpg) 
**Subscribe to the RSS Feed**: [http://blogs.msdn.com/b/codefx/rss.aspx?tags=SampleOfTheDay](http://blogs.msdn.com/b/codefx/rss.aspx?tags=SampleOfTheDay)
 
 
{rss:url=http://blogs.msdn.com/b/codefx/rss.aspx?tags=SampleOfTheDay,max=20,titlesOnly=true}