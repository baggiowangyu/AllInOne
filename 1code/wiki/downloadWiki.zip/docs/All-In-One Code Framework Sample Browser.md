## Sample Browser v2 ![](All-In-One Code Framework Sample Browser_new.png)
CTP download link: [http://1code.codeplex.com/releases/view/60475](http://1code.codeplex.com/releases/view/60475)
![](All-In-One Code Framework Sample Browser_samplebrowser v2.png)

>![](All-In-One Code Framework Sample Browser_samplebrowser.png)
## Sample Browser v1

The new Sample Browser runs on top of All-In-One Code Framework. It is used to facilitate the search of 400+ code samples in the project. Although this first release provides only the **sample search** function, more features such as **sample polling**, and **auto-update** will be added in the near future. 

**Download**: [http://1code.codeplex.com/releases](http://1code.codeplex.com/releases)

The Sample Browser is green and does not require installation. You can find the application in the root folder of the All-In-One Code Framework package. **SampleBrowser2008.exe** is for browsing Visual Studio 2008 code samples, and **SampleBrowser2010.exe** is for Visual Studio 2010 samples. You can launch the application with a simple double click. The application lists all code samples in the main window. Above the samples is a search bar with language filters. The Sample Browser filters samples by looking for your keywords in the sample names and documentations (ReadMe.txt), and displays the search results in the main window. By clicking a sample, its documentation (ReadMe.txt) is displayed in a cool black form. By double-clicking a sample, the sample will be opened in Visual Studio.

If you have any feedback and suggestions for the Sample Browser, please email us: [mailto:onecode@microsoft.com](mailto:onecode@microsoft.com)