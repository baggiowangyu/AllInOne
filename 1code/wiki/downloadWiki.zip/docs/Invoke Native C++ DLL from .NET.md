# {"Invoke Native C++ DLL from .NET Code"}
>{Writer: [Jialiang Ge](http://www.codeplex.com/site/users/view/Jialiang)}>
 
[Solution 1. (Explicit) P/Invoke](http://1code.codeplex.com/wikipage?title=Invoke%20Native%20C%2b%2b%20DLL%20from%20.NET#PInvoke)
[Solution 2. Dynamic P/Invoke](http://1code.codeplex.com/wikipage?title=Invoke%20Native%20C%2b%2b%20DLL%20from%20.NET#DynamicPInvoke)
[Solution 3. Implicit P/Invoke (Use a C++/CLI wrapper)](http://1code.codeplex.com/wikipage?title=Invoke%20Native%20C%2b%2b%20DLL%20from%20.NET#CLIWrapper)
[Solution 4. Convert C++ DLL to a COM server, and call it from .NET code through .NET-COM interop](http://1code.codeplex.com/wikipage?title=Invoke%20Native%20C%2b%2b%20DLL%20from%20.NET#COMInterop)
 
{anchor:PInvoke}
## {"Solution 1. (Explicit) P/Invoke"}
Samples: 
* **CppDynamicLinkLibrary** ({"a native C++ DLL module that exports global data, functions and classes"})
* **CSPInvokeDll** ({"a C# application that P/Invokes the functions exported by CppDynamicLinkLibrary"})
* **VBPInvokeDll** ({"a VB.NET application that P/Invokes the functions exported by CppDynamicLinkLibrary"})
{"Platform Invocation Services (P/Invoke) in .NET allows managed code to call unmanaged functions that are implemented and exported in unmanaged DLLs. The C# sample application CSPInvokeDll and the VB.NET sample application VBPInvokeDll demonstrate P/Invoking the functions exported by the native C++ DLL CppDynamicLinkLibrary.dll."}
 
![Download](Invoke Native C++ DLL from .NET_Download.png|http://1code.codeplex.com/releases) Download the [All-In-One Code Framework (Library)](http://1code.codeplex.com/releases/view/44540#DownloadId=119923) package.
 
![](Invoke Native C++ DLL from .NET_ PInvoke.png)

{anchor:DynamicPInvoke}
## {"Solution 2. Dynamic P/Invoke"}
Samples: 
* **CppDynamicLinkLibrary** ({"a native C++ DLL module that exports global data, functions and classes"})
* **CSLoadLibrary** ({"a C# application that dynamically P/Invokes the functions exported by CppDynamicLinkLibrary"})
* **VBLoadLibrary** ({"a VB.NET application that dynamically P/Invokes the functions exported by CppDynamicLinkLibrary"})
{"Dynamic P/Invoke serves as a supplement for the P/Invoke technique and is useful especially when the target DLL is not in the search path of P/Invoke. If you use P/Invoke, CLR will search the dll in your assembly's directory first, then search the dll in directories listed in PATH environment variable. If the dll is not in any of those directories, you have to use the so called Dynamic P/Invoke technique. Dynamic P/Invoke dynamically loads the native DLL by calling LoadLibrary and gets the address of the target function through GetProcAddress and Marshal.GetDelegateForFunctionPointer. CSLoadLibrary and VBLoadLibrary use the technology to dynamically load and call CppDynamicLinkLibrary."}
 
![Download](Invoke Native C++ DLL from .NET_Download.png|http://1code.codeplex.com/releases) Download the [All-In-One Code Framework (Library)](http://1code.codeplex.com/releases/view/44540#DownloadId=119923) package.
 
![](Invoke Native C++ DLL from .NET_ DynamicPInvoke.png)

{anchor:CLIWrapper}
## {"Solution 3. Implicit P/Invoke (Use a C++/CLI wrapper)"}
Samples: 
* **CppDynamicLinkLibrary** ({"a native C++ DLL module that exports global data, functions and classes"})
* **CppCLINativeDllWrapper** ({"a C++/CLI wrapper of the native C++ DLL CppDynamicLinkLibrary"})
* **CSCallNativeDllWrapper** ({"a C# application that invokes CppDynamicLinkLibrary through CppCLINativeDllWrapper"})
* **VBCallNativeDllWrapper** ({"a VB.NET application that invokes CppDynamicLinkLibrary through CppCLINativeDllWrapper"})
{"The interoperability features supported by Visual C++/CLI offer a particular advantage over other .NET languages when it comes to interoperating with native modules. Apart from the traditional"} [explicit P/Invoke](http://1code.codeplex.com/wikipage?title=Invoke%20Native%20C%2b%2b%20DLL%20from%20.NET#PInvoke){", C++/CLI allows implicit P/Invoke, also known as C++ Interop, or It Just Work (IJW), which mixes managed code and native code almost invisibly. The feature provides better type safety, easier coding, greater performance, and is more forgiving if the native API is modified. You can use the technology to build .NET wrappers for native C++ classes and functions if their source code is available, and allow any .NET clients to access the native C++ classes and functions through the wrappers. "}
 
![Download](Invoke Native C++ DLL from .NET_Download.png|http://1code.codeplex.com/releases) Download the [All-In-One Code Framework (Library)](http://1code.codeplex.com/releases/view/44540#DownloadId=119923) package.
 
![](Invoke Native C++ DLL from .NET_ CLIWrapper.png)

{anchor:COMInterop}
## {"Solution 4. Convert C++ DLL to a COM server, and call it from .NET code through .NET-COM interop"}
Samples: 
* **ATLDllCOMServer** ({"a native C++ DLL converted to an in-process COM server"})
* **CSCOMClient** ({"a C# application that invokes the C++ in-process COM server ATLDllCOMServer"})
* **VBCOMClient** ({"a VB.NET application that invokes the C++ in-process COM server ATLDllCOMServer"})
{"The .NET sample applications CSCOMClient and VBCOMClient invoke the in-process COM server ATLDllCOMServer that was converted from a native C++ DLL."}
 
![Download](Invoke Native C++ DLL from .NET_Download.png|http://1code.codeplex.com/releases) Download the [All-In-One Code Framework (COM)](http://1code.codeplex.com/releases/view/44540#DownloadId=119919) package.
 
![](Invoke Native C++ DLL from .NET_ COMInterop.png)